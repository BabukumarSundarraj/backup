import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class Creating_XML {
	public static void main(String[] args)
	{
		try{
			DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
			DocumentBuilder db=dbf.newDocumentBuilder();
			Document d=db.newDocument();
			
			Element rootElement=d.createElement("cars");
			d.appendChild(rootElement);
			
			Element nestedElement1=d.createElement("Amazing_cars");
			rootElement.appendChild(nestedElement1);
			
			Attr attr1=d.createAttribute("company");
			attr1.setValue("ferrari");
			nestedElement1.setAttributeNode(attr1);
			
			Element ferrari1=d.createElement("purpose1");
			nestedElement1.appendChild(ferrari1);
			
			Attr attr2=d.createAttribute("for");
			attr2.setNodeValue("Formula_one");
			ferrari1.setAttributeNode(attr2);
			
			ferrari1.appendChild(d.createTextNode("5577"));
			
			Element ferrari2=d.createElement("purpose2");
			nestedElement1.appendChild(ferrari2);
			
			Attr attr3=d.createAttribute("for");
			attr3.setNodeValue("Advertisement");
			ferrari2.setAttributeNode(attr3);
			
			ferrari2.appendChild(d.createTextNode("0051"));
			
			
			TransformerFactory tf=TransformerFactory.newInstance();
			Transformer t=tf.newTransformer();
			
			DOMSource ds=new DOMSource(d);
			StreamResult st=new StreamResult(new File("E:\\XML_Files\\cars.xml"));
			
			t.transform(ds,st);
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
