package Form;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

public class UserForm extends ActionForm{
	private int roll_no;
	private String name;
	private String dept;
	private String password;
	private String image;
	public int getRoll_no() {
		return roll_no;
	}
	public void setRoll_no(int roll_no) {
		this.roll_no = roll_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	public ActionErrors validate(ActionMapping mapping,
            HttpServletRequest request) {
        ActionErrors errors = new ActionErrors();
 
        if (name == null || name.length() == 0) {
            errors.add("name", new ActionMessage("name.not.entered"));
        }
        
        
        if (dept == null || dept.length() == 0) {
            errors.add("dept", new ActionMessage("dept.not.entered"));
        }
        if (roll_no == 0) {
            errors.add("roll_no", new ActionMessage("roll_no.not.entered"));
        }
        if (image == null || image.length() == 0) {
            errors.add("image", new ActionMessage("image.not.entered"));
        }
        
        int count1=0,count2=0,count3=0,count4=0;
        for(int i=0;i<password.length();i++)
        {
        	if(password.charAt(i)>='a' && password.charAt(i)<='z')
        	{
        		count1++;
        	}
        	else if(password.charAt(i)>='A' && password.charAt(i)<='Z')
        	{
        		count2++;
        	}
        	else if(password.charAt(i)>='0' && password.charAt(i)<='9')
        	{
        		count3++;
        	}
        	else{
        		count4++;
        	}
        }
        if (password == null || password.length() == 0) {
            errors.add("password", new ActionMessage("password.not.entered"));
        }
        else if(password.length()<8)
        {
        	errors.add("password",new ActionMessage("password.not.long"));
        }
        else if(count1==0 || count2==0 || count3==0 || count4==0)
        {
        	errors.add("password",new ActionMessage("password.not.correct"));
        }
 
        return errors;
    }
	
	
	
}
