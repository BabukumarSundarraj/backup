package Dao;

import java.sql.*;

public class UserDAO {
	public String insertdata(int roll_no,String name,String dept,String image)throws Exception
	{
		Connection c = null;
		try  {
			Class.forName("org.postgresql.Driver");
		    c = DriverManager
		            .getConnection("jdbc:postgresql://localhost:5432/postgres",
		            "postgres", "root");
		    Statement statement = c.createStatement();
			statement.executeUpdate("insert into student (roll_no,name,dept,image) "+ "VALUES " + "('" + roll_no + "', '" + name + "', '" + dept + "', '" + image + "')");
		}
		catch(SQLException e){
			
			System.out.println("Connection failed!!!");
			e.printStackTrace();
			return "notokay";
		}
		return "okay";
	}

}
