package test;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

import Dao.UserDAO;
import Form.UserForm;

public class TestAction extends Action {

public ActionForward execute(ActionMapping mapping, ActionForm form,
	HttpServletRequest request, HttpServletResponse response) throws Exception {
	  UserForm uf=(UserForm) form;
		int roll_no=uf.getRoll_no();
		String name=uf.getName();
		String dept=uf.getDept();
		String image=uf.getImage();
		
		

		
		
//		String dirName="E:\\Image\\";
//		ByteArrayOutputStream baos=new ByteArrayOutputStream(1000);
//        BufferedImage img=ImageIO.read(new File(dirName,"img1.jpg"));
//        ImageIO.write(img, "jpg", baos);
//        baos.flush();
//
//        String base64String=Base64.encode(baos.toByteArray());
//        baos.close();
//
//        byte[] bytearray = Base64.decode(base64String);
//        
//        BufferedImage imag=ImageIO.read(new ByteArrayInputStream(bytearray));
//        ImageIO.write(imag, "jpg", new File(dirName,"snap.jpg"));
        
        
        
        
//		BufferedImage image2=ImageIO.read(new File("E:\\Image\\img1.jpg"));
//		ByteArrayOutputStream bos1=new ByteArrayOutputStream();
//		ImageIO.write(image2, "jpg", bos1);
//		byte[] res1=bos1.toByteArray();
//		String encodedImage1 = Base64.encode(bos1.toByteArray());
//		
		
		
		
		
		
//		System.out.println(encodedImage1);
		
		
		
		//converting url to byte 
//		File f1=new File(image);
//		FileInputStream fis=new FileInputStream(f1);
//		ByteArrayOutputStream bos=new ByteArrayOutputStream();
//		byte[] buf=new byte[1024];
//		try {
//			for (int readNum; (readNum = fis.read(buf)) != -1;) {
//						bos.write(buf, 0, readNum);    
//			           }
//		    } catch (IOException ex) {
//		    }
//	    byte[] bytes = bos.toByteArray();
//			
//		HttpSession ses = request.getSession(true);
//		ses.setAttribute("image",encodedImage1);
//		ses.setAttribute("image1",res1);
//		
//		
//		UserDAO ud=new UserDAO();
//		String s=ud.insertdata(roll_no, name, dept,encodedImage1);
//		if(s.equals("okay"))
//		{
//		return mapping.findForward("success");
//		}
//		else {
//			return mapping.findForward("failure");
//		}
        return mapping.findForward("success");
	}

}