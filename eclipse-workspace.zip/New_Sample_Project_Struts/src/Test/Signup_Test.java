package Test;

import javax.servlet.http.HttpServletRequest;
import Form.*;
import DAO.*;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class Signup_Test extends Action {
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Signup_Form sf=(Signup_Form) form;
		String name=sf.getName();
		String username=sf.getUsername();
		String mailid=sf.getMailid();
		String password=sf.getPassword();
		
		
		Signup_DAO sd=new Signup_DAO();
		String check1=sd.check_data(username,password);
		if(check1.equals("true"))
		{
			System.out.println("true");
			String a=sd.insert_signup_data(name, username, mailid, password);
			return mapping.findForward("success");
		}
		else {
			return mapping.findForward("failure");
		}
		
		
	 
	}

}
