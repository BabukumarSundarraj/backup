package Test;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import Form.*;
import DAO.*;

public class Adduser_Test extends Action {
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		
		HttpSession session=request.getSession();
		
		
		Adduser_Form af=(Adduser_Form) form;
		String username=af.getUsername();
		
		
		String username_login=session.getAttribute("username_login").toString();
		
		
		Adduser_DAO ad=new Adduser_DAO();
		String check=ad.Check_Adduser_Tochat(username_login,username);
		if(check.equals("false")) {
			
			
		}
		else {
			String Accepted =username;
			Accepted+=check;
			System.out.println(Accepted);
		}
		System.out.println(username);
		String check1=ad.Check_Acceptuser_Tochat(username, username_login).toString();
		if(check1.equals("false")) {
			
			
		}
		else {
			String Need_to_accept=check1;
			System.out.println(Need_to_accept);
		}
		return mapping.findForward("success");
	}
}
