package Test;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import DAO.Login_DAO;
import Form.Login_Form;

public class Login_Test extends Action{
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
	 HttpSession session=request.getSession();
	 
	 Login_Form lf=(Login_Form) form;
	 String username=lf.getUsername();
	 String password=lf.getPassword();
	 session.setAttribute("username_login",username);
	 Login_DAO ld=new Login_DAO();
	 String a=ld.read_signup_data(username,password);
	 if(a.equals("true"))
	 {
		 return mapping.findForward("success");
	 }
	 else
	 {
	return mapping.findForward("failure");
	 }
	}
}
