package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Login_DAO {
	public String read_signup_data(String username,String password)throws Exception {
		Connection c=null;
		try {
			Class.forName("org.postgresql.Driver");
		    c = DriverManager
		            .getConnection("jdbc:postgresql://localhost:5432/postgres",
		            "postgres", "root");
		    Statement s = c.createStatement();
		    ResultSet rs=s.executeQuery("select * from Signup");
		    int count1=0,count2=0;
		    while(rs.next())
		    {
		    	String username1=rs.getString("username");
		    	String password1=rs.getString("password");
		    	String username2=username;
		    	String password2=password;
		    	if(username2!=null && password!=null)
		    	{
		    	int com1=username2.compareTo(username1);
		    	int com2=password2.compareTo(password1);
		    	if(com1==0 && com2==0)
		    	{
		    		count1++;
		    		count2++;
		    		break;
		    	}
		    	}
		    }
		    if(count1!=0 && count2!=0)
		    {
		    	return "true";
		    }
		    else {
		    	return "false";
		    }
		    
		    }
		catch(SQLException e){
			e.printStackTrace();
		}
		return "false";
	}
}
