package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Signup_DAO {
	public String insert_signup_data(String name,String username,String mailid,String password) throws Exception
	{
		Connection c = null;
		try  {
			Class.forName("org.postgresql.Driver");
		    c = DriverManager
		            .getConnection("jdbc:postgresql://localhost:5432/postgres",
		            "postgres", "root");
		    Statement s = c.createStatement();
		    s.executeUpdate("create table if not exists Signup(name text not null,username text not null,mailid text not null,password text not null)");
		    s.executeUpdate("insert into Signup (name,username,mailid,password) "+ "VALUES " + "('" + name + "', '" + username + "', '" + mailid + "', '" + password + "')");
			}
		catch(SQLException e)
			{
				e.printStackTrace();
			}
		return "false";
	}
	
	public String check_data(String username,String password) throws Exception
	{
		Connection c=null;
		try {
			Class.forName("org.postgresql.Driver");
		    c = DriverManager
		            .getConnection("jdbc:postgresql://localhost:5432/postgres",
		            "postgres", "root");
		    Statement s = c.createStatement();
		    ResultSet rs=s.executeQuery("select * from Signup");
		    int count1=0,count2=0;
		    while(rs.next())
		    {
		    	String username1=rs.getString("username");
		    	String password1=rs.getString("password");
		    	String username2=username;
		    	String password2=password;
		    	if(username2!=null && password!=null)
		    	{
		    	int com1=username2.compareTo(username1);
		    	int com2=password2.compareTo(password1);
		    	if(com1==0)
		    	{
		    		count1++;
		    		break;
		    	}
		    	}
		    }
		    if(count1!=0)
		    {
		    	return "false";
		    }
		    else {
		    	return "true";
		    }
		    
		    }
		catch(SQLException e){
			e.printStackTrace();
		}
		return "false";
	}
	

}
