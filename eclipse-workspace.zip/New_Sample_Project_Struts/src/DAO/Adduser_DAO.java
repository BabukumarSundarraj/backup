package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Adduser_DAO {
public String Adduser_Tochat(String username,String username_login)throws Exception {
	Connection c=null;
	try {
	Class.forName("org.postgresql.Driver");
    c = DriverManager
            .getConnection("jdbc:postgresql://localhost:5432/postgres",
            "postgres", "root");
    Statement s = c.createStatement();
    
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	return "true";
}
public String Check_Adduser_Tochat(String username_login,String username)throws Exception {
	Connection c=null;
	try {
	Class.forName("org.postgresql.Driver");
    c = DriverManager
            .getConnection("jdbc:postgresql://localhost:5432/postgres",
            "postgres", "root");
    Statement s = c.createStatement();
    s.executeUpdate("create table if not exists Add_user(username_login text not null,username text not null)");
    
    ResultSet rs=s.executeQuery("select * from Add_user where username_login=('"+username_login +"')");
    
    int count1=0; 
    String added_user="";
    while(rs.next())
    {
    	count1++;
    	added_user=rs.getString("username");
    	return added_user;
    }
    if(count1==0)
    {
    	s.executeUpdate("insert into Add_user (username_login,username) "+ "VALUES " + "('" + username_login + "', '" + username + "')");
    	return "false";
    }
    
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	return "true";
}
public String Check_Acceptuser_Tochat(String username, String username_login)throws Exception {
	Connection c=null;
	try {
	Class.forName("org.postgresql.Driver");
    c = DriverManager
            .getConnection("jdbc:postgresql://localhost:5432/postgres",
            "postgres", "root");
    Statement s = c.createStatement();
    s.executeUpdate("create table if not exists Accept_user(username text not null,username_login text not null)");
    s.executeUpdate("delete * from Accept_user");
    s.executeUpdate("delete * from Add_user");
    ResultSet rs=s.executeQuery("select * from Accept_user where username=('"+username +"')");
    
    int count1=0;
    String To_accept="";
    while(rs.next())
    {
    	count1++;
    	To_accept=rs.getString("username_login");
    	return To_accept;
    }
    if(count1==0)
    {
    	s.executeUpdate("insert into Accept_user (username,username_login) "+ "VALUES " + "('" + username + "', '" + username_login + "')");
    	return "false";
    }
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	return "true";
}
}
