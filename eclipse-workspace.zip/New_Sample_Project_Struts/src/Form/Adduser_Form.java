package Form;

import org.apache.struts.action.ActionForm;

public class Adduser_Form extends ActionForm {
	private String username;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
}
