import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;


public class parse_databy_filter {
	public  static void main(String args[]) throws Exception
	{
		Object obj = new JSONParser().parse(new FileReader("C:\\Users\\pcp-int-8\\Desktop\\second.json")); 
		
		JSONObject jo = (JSONObject)obj;
		
		 JSONArray filter_1 = (JSONArray)jo.get("filter1");
		
		 ArrayList<String> filter1=new ArrayList<String>();
		 for(Object obj1:filter_1)
		 {
			 filter1.add(obj1.toString());
		 }
		 
		 JSONArray filter_2 = (JSONArray)jo.get("filter2");
			
		 ArrayList<String> filter2=new ArrayList<String>();
		 for(Object obj1:filter_2)
		 {
			 filter2.add(obj1.toString());
		 }
		
		 JSONArray filter_3 = (JSONArray)jo.get("filter3");
			
		 ArrayList<String> filter3=new ArrayList<String>();
		 for(Object obj1:filter_3)
		 {
			 filter3.add(obj1.toString());
		 }
				

		
		File dir=new File("D:\\logs");
		FileFilter fileFilter = new FileFilter() {
	         public boolean accept(File file) {
	            return file.isDirectory();
	         }
	      };
	    File[] files=dir.listFiles(fileFilter);
	    
	    
	    
	    ArrayList<String> parse_file=new ArrayList<String>();
	    int count1=0;
	    int count2=0;
	    int count3=0;
	    
	    for(int i=0;i<files.length;i++)
	    {
	    	
	    	String a=files[i].toString();
	    	String b=a+"\\logs\\server_info.props";
	    	String b1=a+"\\logs\\";
	    	Scanner build_file = new Scanner(new File(b));
	    	Pattern match1=Pattern.compile(filter1.get(0));
	    	while(build_file.hasNextLine())
	    	{
	    		
	    		String file_line=build_file.nextLine();
	    		Matcher match2=match1.matcher(file_line);
	    		while(match2.find())
	    		{
	    			
	    			String number=file_line.replace("build.number=", "");
	    			if((filter1.get(3)).equals("greater than")) {
	    				if(Integer.parseInt(number)>Integer.parseInt(filter1.get(2)))
	    				{
	    					
	    					count1++;
	    				}
	    			}
	    		}
	    	}
	    	build_file.close();
	    	Scanner os_file= new Scanner(new File(b));
	    	match1=Pattern.compile(filter2.get(0));
	    	while(os_file.hasNextLine())
	    	{
	    		
	    		String file_line=os_file.nextLine();
	    		Matcher match2=match1.matcher(file_line);
	    		while(match2.find())
	    		{
	    			String os_val=file_line.replace("server.os=", "");
	    			if(os_val.equals(filter2.get(2)))
	    				{
	    					count2++;
	    				}
	    		}
	    	}
	    	os_file.close();
	    	Scanner license_file= new Scanner(new File(b));
	    	match1=Pattern.compile(filter3.get(0));
	    	while(license_file.hasNextLine())
	    	{
	    		
	    		String file_line=license_file.nextLine();
	    		Matcher match2=match1.matcher(file_line);
	    		while(match2.find())
	    		{
	    			String license_val=file_line.replace("license.computer.count=", "");
	    			if((filter3.get(3)).equals("lesser than")) {
	    				if(Integer.parseInt(license_val)<Integer.parseInt(filter3.get(2)))
	    				{
	    					count3++;
	    				}
	    			}
	    		}
	    	}
	   
	    	
	    	if(count1>0 && count2>0 && count3>0)
	    	{
	    		parse_file.add(b1);
	    	}
	    	
	    	count1=0;
	    	count2=0;
	    	count3=0;
	    	
	    }
	    System.out.println("______________________________file to parse______________________________________");
	    for(int i=0;i<parse_file.size();i++)
	    {
	    	System.out.println(parse_file.get(i));
	    }
	    System.out.println("\n\n");
	    System.out.println("______________________________errors and file_location______________________________________");
	    ArrayList<String> error_file=new ArrayList<String>();
	    
	    for(int j=0;j<parse_file.size();j++)
	    {
	    int count4=0;
	    int count5=0;
	    int count6=0;
	    String error1=jo.get("error_file1").toString();
	    String[] error_1=error1.split("::");
	    Scanner build_file = new Scanner(new File(parse_file.get(j)+error_1[0].trim()+".log"));
	    Pattern match1=Pattern.compile(error_1[1].trim());
	    while(build_file.hasNext())
	    {
	    	String file_line=build_file.nextLine();
	    	Matcher match2=match1.matcher(file_line);
	    	while(match2.find())
	    	{
	    		count4++;
	    		System.out.println(file_line+"\n");
	    	}
	    }
	    build_file.close();
	    
	    
	    String error2=jo.get("error_file2").toString();
	    String[] error_2=error2.split("::");
	    Scanner build_file1 = new Scanner(new File(parse_file.get(j)+error_2[0].trim()+".log"));
	    match1=Pattern.compile(error_2[1].trim());
	    while(build_file1.hasNext())
	    {
	    	String file_line=build_file1.nextLine();
	    	Matcher match2=match1.matcher(file_line);
	    	while(match2.find())
	    	{
	    		count5++;
	    		System.out.println(file_line+"\n");
	    	}
	    }
	    build_file1.close();
	    
	    
	    
	    String error3=jo.get("error_file3").toString();
	    String[] error_3=error3.split("::");
	    Scanner build_file3 = new Scanner(new File(parse_file.get(j)+error_3[0].trim()+".log"));
	    match1=Pattern.compile(error_3[1].trim());
	    while(build_file3.hasNext())
	    {
	    	String file_line=build_file3.nextLine();
	    	Matcher match2=match1.matcher(file_line);
	    	while(match2.find())
	    	{
	    		count6++;
	    		System.out.println(file_line+"\n");
	    	}
	    }
	    build_file3.close();
	    if(count4>0 && count5>0 && count6>0)
	    {
	    	System.out.println(parse_file.get(j)+error_3[0].trim()+".log");
	    	System.out.println("\n\n");
	    	error_file.add(parse_file.get(j));
	    }
	    }
	   
	    System.out.println("__________________________________________error occered in user_folder_________________________________");
	    for(int i=0;i<error_file.size();i++)
	    {
	    	System.out.println(error_file.get(i));
	    }
	    System.out.println("__________________________________________end_________________________________");
	}


}
