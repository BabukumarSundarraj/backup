import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Parsing_xml {
	public static void main(String argv[]) {
		try {
			File file = new File("D:\\user_info.xml");
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document d = db.parse(file);
			
			d.getDocumentElement().normalize();
			
			//parsing the xml
			
			NodeList list = d.getElementsByTagName("filter");
			Node node1 = list.item(0);
			Element element1=(Element) node1;
			String name_start=(element1.getElementsByTagName("starts_with").item(0).getTextContent()).toString().trim();
			
			
			List<String> textFiles1 = new ArrayList<String>();
			
			List<String> textFiles = new ArrayList<String>();
	    	File dir = new File("D:\\server_info");
	    	for (File file1 : dir.listFiles()) {
    		    if (file1.getName().startsWith(name_start)) {
    		      textFiles.add(file1.getName());
    		    }
    		  }
	    	
	    	
	    	
	    	// parsing the required file by the given filter
			
			for(int i=0;i<list.getLength();i++)
			{
				
				
				String build_number= (element1.getElementsByTagName("build.number").item(0).getTextContent()).toString();
				String db_name=(element1.getElementsByTagName("db.user.name").item(0).getTextContent()).toString();
				
				build_number=(build_number).trim();
				db_name=(db_name).trim();
				
				String[] db_names=db_name.split(",");
				String Dir="D:\\server_info";
				for(int j=0;j<textFiles.size();j++)
				{
					String Dir1=Dir+"\\"+textFiles.get(j);
					Scanner file2 = new Scanner(new File(Dir1));
					Pattern match1=Pattern.compile("build.number");
					while(file2.hasNextLine())
			    	{
						String file_line=file2.nextLine();
						Matcher match2=match1.matcher(file_line);
						if(match2.find())
						{
							if(build_number.startsWith(">"))
							{
							String build_number1=build_number;
							build_number1=build_number1.replace(">", "");
							file_line=file_line.replace("build.number=", "");
							int a=Integer.parseInt(file_line);
							int b=Integer.parseInt(build_number1);
							if(a>b)
								{
									textFiles1.add(textFiles.get(j));
								}
							}
						}
						
			    	}
				}
			}
			
			
			
			// displaying the required content
			
			NodeList list1 = d.getElementsByTagName("installation");
			Node node2 = list1.item(0);
			String read_content=node2.getNodeName();
			Pattern match3=Pattern.compile(read_content);
			String Dir="D:\\server_info";
			for(int i=0;i<textFiles1.size();i++)
			{
				
				String Dir1=Dir+"\\"+textFiles1.get(i);
				Scanner file2 = new Scanner(new File(Dir1));
				int count1=0;
				while(file2.hasNextLine())
				{
					String file_line=file2.nextLine();
					Matcher match2=match3.matcher(file_line);
					if(match2.find())
					{
						count1++;
						if(count1==1)
						{
							System.out.println(textFiles1.get(i));
							System.out.println("");
						}
						
						System.out.println(file_line);
						
					}
				}
				System.out.println("");
				System.out.println("");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
