import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.stream.Stream;

public class Stream_file_check {
	public static void main(String args[])throws IOException
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(dtf.format(now));
		 String fileName = "D:\\\\New folder\\\\build1_05.log";
		 File file = new File(fileName);
		 String file_value=""; 
		 try {
			 Stream linesStream = Files.lines(file.toPath());
			 linesStream.forEach(line -> {
			        if(line.toString().contains("BUILD SUCCESS"))
			        {
			        	System.out.println("Hai");
			        }
			      });
		    }
		 catch(Exception e)
		 {
			 e.printStackTrace();
		 }
		now = LocalDateTime.now();  
		System.out.println(dtf.format(now));
	}
}
