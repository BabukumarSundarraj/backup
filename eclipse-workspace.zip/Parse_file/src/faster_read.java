import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
public class faster_read {
	
	public static void main(String args[])throws IOException
	{
		BufferedWriter out = new BufferedWriter( 
                new FileWriter("D:\\out5.txt")); 
		Date date = new Date();

	      
	    out.write(date.toString());
		BufferedReader reader = new BufferedReader(new FileReader("D:\\logs\\user3 - Copy\\logs\\nginx_error_19.log"));
		StringBuilder stringBuilder = new StringBuilder();
		char[] buffer = new char[10];
		while (reader.read(buffer) != -1) {
			stringBuilder.append(new String(buffer));
			buffer = new char[10];
		}
		reader.close();

		String content = stringBuilder.toString();

		if(content.contains("l value required error"))
		{
			System.out.println("Hai");
		}
		BufferedReader reader1 = new BufferedReader(new FileReader("D:\\logs\\user3 - Copy\\logs\\nginx_error_20.log"));
		StringBuilder stringBuilder1 = new StringBuilder();
		char[] buffer1 = new char[10];
		while (reader1.read(buffer1) != -1) {
			stringBuilder1.append(new String(buffer1));
			buffer1 = new char[10];
		}
		reader1.close();

		String content1 = stringBuilder1.toString();
		if(content1.contains("run time error"))
		{
			System.out.println("Hai");
		}
		BufferedReader reader2 = new BufferedReader(new FileReader("D:\\logs\\user3 - Copy\\logs\\nginx_error_21.log"));
		StringBuilder stringBuilder2 = new StringBuilder();
		char[] buffer2 = new char[10];
		while (reader2.read(buffer2) != -1) {
			stringBuilder2.append(new String(buffer2));
			buffer2 = new char[10];
		}
		reader2.close();

		String content2 = stringBuilder2.toString();
		if(content2.contains("compiler error"))
		{
			System.out.println("Hai");
		}
		Date date1 = new Date();
		out.newLine();
		out.write(date1.toString());
	     out.close(); 
    }
}
