import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class Displaying_all_files {  
	
	
    public static void main(String args[])throws Exception{
    	try {
    	File file=new File("D:\\mickey5.txt");
    	String file_content_old="";
    	BufferedReader br=new BufferedReader(new FileReader(file));
    	
    
    	String sep_line=br.readLine();
    	while(sep_line!=null)
    	{
    		file_content_old= file_content_old + sep_line + System.lineSeparator();
    		sep_line=br.readLine();
    	}
    	System.out.println(file_content_old);
    	String file_content_new= file_content_old.replaceAll("te", "ppp");
    	System.out.println("");
    	System.out.println("");
    	System.out.println(file_content_new);
    	BufferedWriter out= new BufferedWriter(new FileWriter("D:\\mickey5.txt")); 
    	out.write(file_content_new);
    	
    	out.close();
    	br.close();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }    
}  