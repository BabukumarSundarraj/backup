import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class File_byte_check {
	  public static void main(String [] pArgs) throws IOException {
		  	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
			LocalDateTime now = LocalDateTime.now();  
			System.out.println(dtf.format(now));
		    String fileName = "D:\\New folder\\build1_07.log";
		    File file = new File(fileName);
		 
		    byte [] fileBytes = Files.readAllBytes(file.toPath());
		    char singleChar;
		    String file_value="";
		    for(byte b:fileBytes)
		    {
		    	singleChar = (char) b;
		    	file_value+=singleChar;
		    }
		    Pattern match1=Pattern.compile("BUILD SUCCESS");
			Matcher match2=match1.matcher(file_value);
			while(match2.find())
			{
				System.out.println("Hai");
			}
			now = LocalDateTime.now();  
			System.out.println(dtf.format(now));
	  }
}
