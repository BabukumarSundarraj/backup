import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class Directory_Displaying { 
   public static void main(String[] args) {
	   try {
	    	File file=new File("D:\\mickey6.txt");
	    	String file_content_old="";
	    	BufferedReader br=new BufferedReader(new FileReader(file));
	    	File file_temp=new File("D:\\temp_mickey6.txt");
	    	BufferedWriter out= new BufferedWriter(new FileWriter(file_temp));
	    	String sep_line;
	    	
	    	
	    	while((sep_line=br.readLine())!=null)
	    	{
	    		out.write(sep_line.replaceAll("te", "ppp"));
	    		out.newLine();
	    	}
	    	
	    	 
	    	out.close();
	    	br.close();
	    	
	    	
	    	Files.move(file_temp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
	    	
	    	file_temp.delete();
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
   }
}