import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Buffer_Reader_check {
	public static void main(String args[])throws IOException
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(dtf.format(now));
		BufferedReader reader1 = new BufferedReader(new FileReader("D:\\New folder\\build1_05.log"));
		StringBuilder stringBuilder1 = new StringBuilder();
		char[] buffer1 = new char[10];
		while (reader1.read(buffer1) != -1) {
			stringBuilder1.append(new String(buffer1));
			buffer1 = new char[10];
		}
		Pattern match1=Pattern.compile("BUILD SUCCESS");
		Matcher match2=match1.matcher(stringBuilder1);
		while(match2.find())
		{
			System.out.println("Hai");
		}
		reader1.close();
		now = LocalDateTime.now();  
		System.out.println(dtf.format(now));
	}
}
