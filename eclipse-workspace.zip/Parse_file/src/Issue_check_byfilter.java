import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Issue_check_byfilter {
	
	public static File[] filtered_file(File[] files,Map filter_find) 
	{
		ArrayList<String> parse_file=new ArrayList<String>();
		File[] filtered_file=files;
		
		Iterator<Map.Entry> itr1 = filter_find.entrySet().iterator(); 
		Hashtable<String,String> filtered_table=new Hashtable<String,String>();
		
		while (itr1.hasNext()) { 
            Map.Entry pair = itr1.next(); 
            filtered_table.put(pair.getKey().toString(),pair.getValue().toString() );
		}
		int count1=0;
		for(int i=0;i<files.length;i++)
		{
			if(files[i]!=null)
			{
			String a=files[i].toString();
	    	String b=a+"\\logs\\server_info.props";
	    	try {
				Scanner build_file = new Scanner(new File(b));
				Pattern match1=Pattern.compile(filtered_table.get("name"));
				while(build_file.hasNextLine())
		    	{
		    		
		    		String file_line=build_file.nextLine();
		    		Matcher match2=match1.matcher(file_line);
		    		while(match2.find())
		    		{
		    			
		    			String value=file_line.replace(filtered_table.get("name")+"=", "");
		    			if((filtered_table.get("type").toLowerCase()).equals("integer"))
		    			{
		    				if(filtered_table.get("compare").equals(">"))
		    				{
		    					if(Integer.parseInt(value)>Integer.parseInt(filtered_table.get("value")))
		    					{
		    						count1++;
		    					}
		    				}
		    				else if(filtered_table.get("compare").equals(">="))
		    				{
		    					if(Integer.parseInt(value)>=Integer.parseInt(filtered_table.get("value")))
		    					{
		    						count1++;
		    					}
		    				}
		    				else if(filtered_table.get("compare").equals("<"))
		    				{
		    					if(Integer.parseInt(value)<Integer.parseInt(filtered_table.get("value")))
		    					{
		    						count1++;
		    					}
		    				}
		    				else if(filtered_table.get("compare").equals("<="))
		    				{
		    					if(Integer.parseInt(value)<=Integer.parseInt(filtered_table.get("value")))
		    					{
		    						count1++;
		    					}
		    				}
		    				else if(filtered_table.get("compare").equals("=="))
		    				{
		    					if(Integer.parseInt(value)==Integer.parseInt(filtered_table.get("value")))
		    					{
		    						count1++;
		    					}
		    				}
		    				else if(filtered_table.get("compare").equals("!="))
		    				{
		    					if(Integer.parseInt(value)!=Integer.parseInt(filtered_table.get("value")))
		    					{
		    						count1++;
		    					}
		    				}
		    			}
		    			else if((filtered_table.get("type").toLowerCase()).equals("string"))
		    			{
		    				if((filtered_table.get("compare").toLowerCase()).equals("startswith"))
		    				{
		    					if(value.startsWith(filtered_table.get("value")))
			    				{
			    					count1++;
			    				}
		    				}
		    				else if((filtered_table.get("compare").toLowerCase()).equals("endswith"))
		    				{
		    					if(value.endsWith(filtered_table.get("value")))
			    				{
			    					count1++;
			    				}
		    				}
		    				else if((filtered_table.get("compare").toLowerCase()).equals("equal"))
		    				{
		    					if(value.equals(filtered_table.get("value")))
			    				{
			    					count1++;
			    				}
		    				}
		    				
		    			}
		    			
		    		}
		    	}
			} 
	    	catch (FileNotFoundException e) {
				e.printStackTrace();
			}
	    	
	    	if(count1>0)
	    	{
	    		parse_file.add(files[i].toString());
	    		count1=0;
	    		
	    	}
			}
		}
		
		for(int i=0;i<filtered_file.length;i++)
		{
			int check=0;
			int j;
			for(j=0;j<parse_file.size();j++)
			{
				if(filtered_file[i]!=null)
				{
				if((filtered_file[i].toString()).equals(parse_file.get(j)))
				{
					check++;
					break;
				}
				}
				
			}
			if(check==0 && filtered_file[i]!=null)
			{
				
				for(int k=i;k<filtered_file.length;k++)
				{
					if(k!=(filtered_file.length)-1)
					{
					filtered_file[k]=filtered_file[k+1];
					}
					else {
						filtered_file[k]=null;
					}
				}
				i=i-1;
			}
		}

		return filtered_file;
	}
	
	public static ArrayList<String> filter_file(Map issue_check)
	{
		File dir=new File("D:\\logs");
		FileFilter fileFilter = new FileFilter() {
	         public boolean accept(File file) {
	            return file.isDirectory();
	         }
	      };
	    File[] files=dir.listFiles(fileFilter);
	    
	    int count1=1;
	    Map filter_find=((Map)issue_check.get("filter"+count1));
	    while(filter_find!=null)
	    {
	    	files=filtered_file(files,filter_find);
	    	count1++;
	    	filter_find=((Map)issue_check.get("filter"+count1));
	    	
	    }
		ArrayList<String> filter_file=new ArrayList<String>();
		
		
		for(int i=0;i<files.length;i++)
	    {
			if(files[i]!=null)
			{
				filter_file.add(files[i].toString());
			}
	    }
		
		
		return filter_file;
	}
	
	public static String display(String file_dir,Map issue_check)
	{
		System.out.println(file_dir+"\n");
		int count1=1;
		int count2=0;
		Map file_error=((Map)issue_check.get("error_file"+count1));
		while(file_error!=null)
	    {			  
			Iterator<Map.Entry> itr1 = file_error.entrySet().iterator(); 
			Hashtable<String,String> filtered_table=new Hashtable<String,String>();
			while (itr1.hasNext()) { 
	            Map.Entry pair = itr1.next(); 
	            filtered_table.put(pair.getKey().toString(),pair.getValue().toString() );
			}
			File dir=new File(file_dir+"\\logs");
			File[] files=dir.listFiles();
			
			if(filtered_table.size()==1)
			{
				
					try
					{
						String dir1=file_dir+"\\logs\\*";
						
						String command = "powershell.exe grep '"+filtered_table.get("error")+"' '"+dir1+"'";

				        
				        Process powerShellProcess = Runtime.getRuntime().exec(command);
				       
				        powerShellProcess.getOutputStream().close();
				        String line;
				        
				        BufferedReader stdout = new BufferedReader(new InputStreamReader(powerShellProcess.getInputStream()));
				        
				        while ((line = stdout.readLine()) != null) {
				        	System.out.println(filtered_table.get("error"));
				        	
				        	count2++;
				        	
				        }
				        stdout.close();
//				        
//						BufferedReader reader1 = new BufferedReader(new FileReader(files[i].toString()));
//						StringBuilder stringBuilder1 = new StringBuilder();
//						char[] buffer1 = new char[10];
//						while (reader1.read(buffer1) != -1) {
//							stringBuilder1.append(new String(buffer1));
//							buffer1 = new char[10];
//						}
//						reader1.close();
//
//						String content1 = stringBuilder1.toString();
//						if(content1.contains(filtered_table.get("error")))
//						{
//							System.out.print(check+"\t");
//							System.out.println(filtered_table.get("error"));
//							count2++;
//						}
//				        
						
					}
					catch(Exception e)
					{
						e.printStackTrace();
					}
					}
			
			else
			{
				for(int i=0;i<files.length;i++)
				{
					String check=files[i].toString().replace(file_dir+"\\logs\\", "");
					
					if(check.startsWith(filtered_table.get("error_file")))
					{
						System.out.print(check+"\t");
						try
						{
//							String dir1=file_dir+"\\logs";
//							String command = "powershell.exe grep '"+filtered_table.get("error")+"' "+check+"";
//
//					       
//					        Process powerShellProcess = Runtime.getRuntime().exec(command);
//					        
//					        powerShellProcess.getOutputStream().close();
//					        String line;
//					        
//					        BufferedReader stdout = new BufferedReader(new InputStreamReader(powerShellProcess.getInputStream()));
//					        while ((line = stdout.readLine()) != null) {
//					        	System.out.println(filtered_table.get("error"));
//					        	count2++;
//					        }
//							stdout.close();
									
							BufferedReader reader1 = new BufferedReader(new FileReader(files[i].toString()));
							StringBuilder stringBuilder1 = new StringBuilder();
							char[] buffer1 = new char[10];
							while (reader1.read(buffer1) != -1) {
								stringBuilder1.append(new String(buffer1));
								buffer1 = new char[10];
							}
							reader1.close();

							String content1 = stringBuilder1.toString();
							if(content1.contains(filtered_table.get("error")))
							{
								System.out.println(filtered_table.get("error"));
								count2++;
							}
							
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
					}
				}
			}
			
			count1++;
	    	file_error=((Map)issue_check.get("error_file"+count1));
	    }
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(dtf.format(now)); 
		System.out.println("\n\n");
		if(count2==(count1)-1)
		{
			return  "true";
		}
		else
		{
			return "false";
		}
		
	}
	
	public static ArrayList<String> display_error(String issue,ArrayList<String> file_filtered,Map issue_check)
	{
		System.out.println(issue + ":" + "\n\n");
		ArrayList<String> error_user=new ArrayList<String>();
		for (int i = 0; i < file_filtered.size(); i++) {
			String return1 = display(file_filtered.get(i),issue_check);
			if (return1.equals("true")) {
				error_user.add(file_filtered.get(i).toString());
			}
		}
		return error_user;
	}
	
	
	public  static void main(String args[]) throws Exception
	{
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(dtf.format(now));  
		
		String json_location="C:\\Users\\pcp-int-8\\Desktop\\second.json";
		
		JSONParser parser = new JSONParser();
				
		Reader reader = new FileReader(json_location);
		
		JSONObject obj = (JSONObject) parser.parse(reader);
		
		
		
		String issue="issue_check";
		String filter="filter";
		String error_file="error_file";
		
		 
		JSONObject jo = (JSONObject) obj; 
		int count1=1;
		Map issue_check= ((Map)jo.get("issue_check"+count1));
		
		while(issue_check!=null)
		{
			ArrayList<String> filter_file=new ArrayList<String>();			
			filter_file=filter_file(issue_check);
			
			
			ArrayList<String> error_user=new ArrayList<String>();
			error_user=display_error("issue_check"+count1,filter_file,issue_check);		
			System.out.println("The below list of usera getting error in the issue"+count1+":"); 
			for(int i=0;i<error_user.size();i++)
			{
				System.out.println(error_user.get(i).replace("D:\\logs\\", ""));
			}
			
			count1++;
			issue_check= ((Map)jo.get("issue_check"+count1));
		}
		now = LocalDateTime.now();
		System.out.println(dtf.format(now)); 
		 
		 

	}
}