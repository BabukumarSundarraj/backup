import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Power_shell_check {
	public static void main(String ars[])throws IOException
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(dtf.format(now));
		String error="BUILD SUCCESS";
		String dir="D:\\New folder\\build1_05.log";
		String command = "powershell.exe grep '"+error+"' '"+dir+"'";
		Process powerShellProcess = Runtime.getRuntime().exec(command);
        
        powerShellProcess.getOutputStream().close();
        String line;
        
        BufferedReader stdout = new BufferedReader(new InputStreamReader(powerShellProcess.getInputStream()));
        while ((line = stdout.readLine()) != null) {
        	if(line.contains("BUILD SUCCESS"))
        	{
            System.out.println("Hai");
        	}
        }
        stdout.close();
        now = LocalDateTime.now();  
		System.out.println(dtf.format(now));
	}
}
