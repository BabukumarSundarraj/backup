import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;  
public class Read_file {  
	
	
	
	
	
    public static void main(String args[])throws Exception{
    	String word="The";
    	int count=1;
    	Pattern match1=Pattern.compile(word,Pattern.CASE_INSENSITIVE);
    	
    	
    	try { 
            BufferedWriter out = new BufferedWriter( 
                          new FileWriter("D:\\out.txt")); 
            out.write("MATCHED OUTPUT  :"); 
            out.newLine();
            out.newLine();
        
         
    	
    	List<String> textFiles = new ArrayList<String>();
    	File dir = new File("D:\\logs");
    	for (File file : dir.listFiles()) {
    		    if (file.getName().endsWith((".txt"))) {
    		      textFiles.add(file.getName());
    		    }
    		  }
    	String Dir="D:\\logs\\";
    	for(int j=0;j<textFiles.size();j++)
    	{
    		Dir+=textFiles.get(j);
    		
    		
    	int  count2=0;
    	Scanner file = new Scanner(new File(Dir));
    	while(file.hasNextLine())
    	{
    		
    		String file_line=file.nextLine();
    		
    		
    		ArrayList<Integer> start=new ArrayList<Integer>();
    		ArrayList<Integer> end=new ArrayList<Integer>();
    		
    		Matcher match2=match1.matcher(file_line);
    		
    		while(match2.find())
    		{
    			start.add(match2.start());
    			end.add(match2.end());
    		}
    		if(start.size()>0)
    		{
    			if(count2==0)
    			{
    				String file_name=textFiles.get(j);
    				out.write(file_name);
    				out.newLine();
    				out.newLine();
    				count2++;
    			}
    			String text_lines="The given text was found at " + count +"th line at the indices :";
    			out.write(text_lines);
    		
    		for(int i=0;i<start.size();i++)
    		{
    			String text_indices=start.get(i)+" "+ end.get(i)+ " ; ";
    			out.write(text_indices);
    		}
    		
    		out.newLine();
    		out.newLine();
    		}
    		count++;
    	}
    	Dir="D:\\logs\\";
    	count=0;
    	count2=0;
    	}
    	out.close(); 
    	}
    	
    	catch (IOException e) { 
            System.out.println("Exception Occurred" + e); 
        }
    }    
}  