import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Power_shell_java {
	public static void main(String args[]) throws IOException{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(dtf.format(now));  

		
		String error="l value required error";
		String dir="D:\\logs\\user3\\logs\\*";
		
		String command = "powershell.exe grep '"+error+"' '"+dir+"'";

        
        Process powerShellProcess = Runtime.getRuntime().exec(command);
        
        powerShellProcess.getOutputStream().close();
        String line;
        
        BufferedReader stdout = new BufferedReader(new InputStreamReader(powerShellProcess.getInputStream()));
        while ((line = stdout.readLine()) != null) {
        	if(line.contains("l value required error"))
        	{
            System.out.println(line);
        	}
        }
        stdout.close();

        System.out.println("Done");
	
		
		now = LocalDateTime.now();  
		System.out.println(dtf.format(now)); 
		try {
		File dir1=new File("D:\\logs\\user3\\logs");
		File[] files=dir1.listFiles();
		
		for(int i=0;i<files.length;i++)
		{
			if(files[i].isFile())
			{
		BufferedReader reader1 = new BufferedReader(new FileReader(files[i].toString()));
		StringBuilder stringBuilder1 = new StringBuilder();
		char[] buffer1 = new char[10];
		while (reader1.read(buffer1) != -1) {
			stringBuilder1.append(new String(buffer1));
			buffer1 = new char[10];
		}
		reader1.close();

		String content1 = stringBuilder1.toString();
		if(content1.contains("l value required error"))
		{
			
			System.out.println("Hai");
			break;
		}
		}
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		now = LocalDateTime.now();  
		System.out.println(dtf.format(now)); 
	}
	 
}
