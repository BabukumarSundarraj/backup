package sample_postgre;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class psql_dbconnection {
	public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "root")) {
 
         
            Statement statement = connection.createStatement();
            System.out.println("Reading Student records");
            
            ResultSet resultSet = statement.executeQuery("SELECT * FROM public.student");
            while (resultSet.next()) {
                System.out.printf(resultSet.getInt("roll_no")+" "+resultSet.getString("name")+" "+resultSet.getString("dept"));
            }
 
        } 
        catch (SQLException e) {
            System.out.println("Connection failure.");
            e.printStackTrace();
        }
    }
}
