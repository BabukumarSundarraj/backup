package array;
import java.util.*;

public class Hashmap {
	public static void main(String args[]) {
		HashMap<Integer, String> hm=new HashMap<Integer , String >();
		hm.put(1,"babu");
		hm.put(3,"kumar");
		hm.put(2,"vicky");
		hm.put(4,"abi");
		System.out.println(hm);
		hm.replace(2,"kumar","sathu");
		System.out.println(hm);
				
	}

}
