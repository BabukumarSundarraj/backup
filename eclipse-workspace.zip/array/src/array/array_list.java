package array;
import java.util.*;
import array.Student;

public class array_list {
	public static void main(String args[])
	{
	ArrayList<String> arrs=new ArrayList<String>();
	arrs.add("ring");
	arrs.add("ring");
	arrs.remove("ring");
	System.out.println(arrs);
	arrs.add("ring");
	arrs.clear();
	System.out.println(arrs);
	
	
		System.out.println(arrs);
	
	
	
	}
}
