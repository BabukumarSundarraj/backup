package array;
import java.util.*;
import array.Student;
import java.io.*;

public class date {
	public static void main(String args[])
	{
		Properties p=new Properties();
		p.put("1", "babu");
		p.put("2", "bab");
		p.put("3", "kumar");
		p.put("4", "abi");
		p.put("5", "jay");
		
		p.list(System.out);
		
		PrintWriter pw=new PrintWriter(System.out);
		
		p.list(pw);
		
		pw.flush();
		
		
		Set s=p.keySet();
		
		Iterator<String> itr=s.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(p.get(itr.next()));
		}
		
		
		
		
		
  	}
}
