package array;

public class Student {
int roll_no;
String name;
String dept;
public Student(int a, String b,String c)
{
	this.roll_no=a;
	this.name=b;
	this.dept=c;
}
}
