package array;
import java.util.*;
public class exception_handling {
public static void main(String args[])
{
	int n;
	Scanner sn=new Scanner(System.in);
	n=sn.nextInt();
	int array[]=new int[n];
	
	try {
		for(int i=0;i<n;i++)
		{
			System.out.println(array[i]);
		}
		System.out.println(0/0);
	}
	catch(ArithmeticException e){
		e.printStackTrace();
	}
	
	sn.close();
}
}
