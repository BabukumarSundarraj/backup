package array;
import java.util.*;
public class sorting_string {
	public static void main(String args[])
	{
		String a="babukumar";
		char array1[]=a.toCharArray();
		Arrays.sort(array1);
		String b="";
		System.out.println(b);
		b+=a;
		System.out.println(b);
		String a1= new String(array1);
		System.out.println(a1);
		Scanner s1=new Scanner(System.in);
		String[] array2=new String[5];
		for (int i=0;i<5;i++)
		{
			array2[i]=s1.nextLine();
		}
		Arrays.sort(array2);
		for (int i=0;i<5;i++)
		{
			System.out.println(array2[i]);
		}
		s1.close();
	}
}
