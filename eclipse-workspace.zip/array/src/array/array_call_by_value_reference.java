package array;
import java.util.*;

public class array_call_by_value_reference {
	void value(int a)
	{
		a+=10;
		System.out.println("----" + a);
	}
	void value (int arr[])
	{
		for(int i=0;i<arr.length;i++)
		{
			arr[i]+=10;
		}
	}
	public static void main(String args[])
	{
		array_call_by_value_reference ob=new array_call_by_value_reference();
		Scanner s1=new Scanner(System.in);
		int[] arr=new int[3];
		for(int i=0;i<3;i++)
		{
			arr[i]=s1.nextInt();
		}
		ob.value(arr[0]);
		System.out.println(arr[0] + "----");
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		ob.value(arr);
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		s1.close();
	}

}
