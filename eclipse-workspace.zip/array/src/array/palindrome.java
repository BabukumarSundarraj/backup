package array;
import java.util.*;
public class palindrome {
	public static void main(String args[]) {
		Scanner s1=new Scanner(System.in);
		String a=s1.nextLine();
		int b=a.length();
		int c=b;
		int count1=0;
		for (int i=0;i<b/2;i++)
		{
			if(a.charAt(i)!= a.charAt(c-1))
			{
				System.out.println("Not a palindrome");
				count1+=1;
			}
			c-=1;
		}
		if(count1==0)
		{
			System.out.println("palindrome");
		}
		s1.close();
	}

}
