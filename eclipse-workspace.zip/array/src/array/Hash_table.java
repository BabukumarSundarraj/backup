package array;
import java.util.*;
import array.Student;

public class Hash_table {
	public static void main(String args[]) {
		ArrayList<String> arrs=new ArrayList<String>();
		Hashtable<Integer,ArrayList> ht=new Hashtable<Integer,ArrayList>();
		arrs.add("babu");
		arrs.add("kumar");
		ht.put(1,arrs);
		Set<Integer> ss=ht.keySet();
		for(int i:ss) {
			for(String j:(ArrayList<String>) ht.get(i))
			{
				System.out.println(j);
			}
		}
		
		
	}

}
 