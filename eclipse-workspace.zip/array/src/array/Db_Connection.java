package array;
import java.sql.*;

public class Db_Connection {
	public static void main(String args[]){  
		try{  
		 
		Connection con=DriverManager.getConnection(  
		"jdbc:mysql://localhost:3306/pro1","root","Babu2034989*");  
		 
		
		}catch(Exception e){ System.out.println(e);}  
		}  
}
