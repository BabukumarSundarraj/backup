package array;

public class call_by_value_reference {
	int data=100;
	public void change(call_by_value_reference cff)
	{
		cff.data=cff.data+100;
	}
	public void change1(int data)
	{
		data=data+100;
	}
public static void main(String args[])
{
	call_by_value_reference cf =new call_by_value_reference();
	call_by_value_reference cf1 =new call_by_value_reference();
	System.out.println(cf.data);
	cf.change1(100);
	System.out.println(cf.data);
	cf.change(cf);
	System.out.println(cf.data);
	cf.change(cf);
	System.out.println(cf.data);
	System.out.println(cf1.data);
}
}
