package array;
import java.util.*;
public class sorting {
public static void main(String args[]) {
	int n;
	Scanner  s1 = new Scanner(System.in);
	n=s1.nextInt();
	int[] intArray=new int[n];
	for(int i=0;i<n;i++)
	{
		intArray[i]=s1.nextInt();
	}
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(intArray[i]>intArray[j])
			{
				int temp=intArray[i];
				intArray[i]=intArray[j];
				intArray[j]=temp;
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		System.out.println(intArray[i]);
	}
	s1.close();
}
}
