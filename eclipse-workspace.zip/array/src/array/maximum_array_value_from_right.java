package array;
import java.util.*;
import java.io.*;
import java.text.*;

public class maximum_array_value_from_right {
	
	
	public static void main(String args[]) throws ParseException {
		Date date=new Date();
		System.out.println(date.toString());
		Date dNow = new Date( );
	    SimpleDateFormat ft =new SimpleDateFormat ("E yyyy.MM.dd 'at' hh:mm:ss a zzz G D k K a z");
	    System.out.println("Current Date: " + ft.format(dNow));
	    
	    SimpleDateFormat st=new SimpleDateFormat("MM.dd.yyyy");
	    Date d1=st.parse("03.31.1999");
	    Date d2=st.parse("10.14.2000");
	    
	    if(d1.before(d2))
	    {
	    	System.out.println("younger");
	    }
	    else if(d1.compareTo(d2)>0 )
	    {
	    	System.out.println("elder");
	    }
	    else
	    {
	    	System.out.println("equal age");
	    }
	}
}