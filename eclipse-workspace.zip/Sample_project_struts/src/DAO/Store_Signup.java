package DAO;

import java.sql.*;

public class Store_Signup {
	public void store_signup(String name,String username,String mailid,String password)
	{
		try{
			Class.forName("org.postgresql.Driver");
			Connection c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres","postgres", "root");
			Statement s=c.createStatement();
			s.executeUpdate("create table if not exists Signup(name text not null,username text primary key not null,mailid text not null, password text not null)");
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}

}
