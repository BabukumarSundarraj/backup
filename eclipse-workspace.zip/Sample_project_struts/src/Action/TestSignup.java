package Action;

import javax.servlet.http.HttpServletRequest;
import Form.*;
import DAO.*;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class TestSignup extends Action {
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Signup_Form sf=(Signup_Form) form;
		String name=sf.getName();
		String username=sf.getUsername();
		String mailid=sf.getMailid();
		String password=sf.getPassword();
		
		
		Store_Signup ss=new Store_Signup();
		
		ss.store_signup(name,username,mailid,password);
		
	 return mapping.findForward("success");
	}

}
